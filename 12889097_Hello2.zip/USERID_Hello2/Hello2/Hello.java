/**
 * This is a simple program for the first lab, to familiarise students
 * with the lab and with plate.
 *
 * @author Raymond Lister
 * @version March 2015
 */
public class Hello
{
    public static void main(String[] args)
    {
        // DO NOT CHANGE THIS LINE OR ANYTHING ABOVE THIS LINE

        System.out.println("Hello! Welcome to Programming Fundamentals.");

        // DO NOT CHANGE THIS LINE OR ANYTHING BELOW THIS LINE
    }
}
